<?php
include("JSON.php");

date_default_timezone_set('Europe/Paris');
//$myH =  date("H:i:s"); ;
$myYear = date("y");
$myMonth = date("m");
$myDay = date("d");



$myH =  date("H");
$myM =  date("i");
$myS =  date("s");

// echo($myTime);
$json["myYear"] = $myYear;
$json["myMonth"] = $myMonth;
$json["myDay"] = $myDay;
$json["myH"] = $myH;
$json["myM"] = $myM;
$json["myS"] = $myS;

header('Content-Type: application/json');
echo json_encode($json);
?>